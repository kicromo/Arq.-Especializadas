# 2025-03-22T01:50:49.881394
import vitis

client = vitis.create_client()
client.set_workspace(path="workDCT")

vitis.dispose()


# 2025-03-22T02:50:14.984625
import vitis

client = vitis.create_client()
client.set_workspace(path="workDCT")

vitis.dispose()


# 2025-03-22T01:58:11.355930
import vitis

client = vitis.create_client()
client.set_workspace(path="workDCT")

vitis.dispose()

vitis.dispose()


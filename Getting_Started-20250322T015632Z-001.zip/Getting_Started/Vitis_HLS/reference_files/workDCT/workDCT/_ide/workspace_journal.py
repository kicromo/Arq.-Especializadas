# 2025-03-18T16:36:53.468428
import vitis

client = vitis.create_client()
client.set_workspace(path="workDCT")

vitis.dispose()


// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XDIFERENCIA_ENERGIA_H
#define XDIFERENCIA_ENERGIA_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xdiferencia_energia_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XDiferencia_energia_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XDiferencia_energia;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XDiferencia_energia_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XDiferencia_energia_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XDiferencia_energia_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XDiferencia_energia_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XDiferencia_energia_Initialize(XDiferencia_energia *InstancePtr, UINTPTR BaseAddress);
XDiferencia_energia_Config* XDiferencia_energia_LookupConfig(UINTPTR BaseAddress);
#else
int XDiferencia_energia_Initialize(XDiferencia_energia *InstancePtr, u16 DeviceId);
XDiferencia_energia_Config* XDiferencia_energia_LookupConfig(u16 DeviceId);
#endif
int XDiferencia_energia_CfgInitialize(XDiferencia_energia *InstancePtr, XDiferencia_energia_Config *ConfigPtr);
#else
int XDiferencia_energia_Initialize(XDiferencia_energia *InstancePtr, const char* InstanceName);
int XDiferencia_energia_Release(XDiferencia_energia *InstancePtr);
#endif

void XDiferencia_energia_Start(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_IsDone(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_IsIdle(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_IsReady(XDiferencia_energia *InstancePtr);
void XDiferencia_energia_Continue(XDiferencia_energia *InstancePtr);
void XDiferencia_energia_EnableAutoRestart(XDiferencia_energia *InstancePtr);
void XDiferencia_energia_DisableAutoRestart(XDiferencia_energia *InstancePtr);

u32 XDiferencia_energia_Get_sigA_0_BaseAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_0_HighAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_0_TotalBytes(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_0_BitWidth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_0_Depth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Write_sigA_0_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Read_sigA_0_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Write_sigA_0_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Read_sigA_0_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Get_sigA_1_BaseAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_1_HighAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_1_TotalBytes(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_1_BitWidth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_1_Depth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Write_sigA_1_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Read_sigA_1_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Write_sigA_1_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Read_sigA_1_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Get_sigA_2_BaseAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_2_HighAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_2_TotalBytes(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_2_BitWidth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_2_Depth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Write_sigA_2_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Read_sigA_2_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Write_sigA_2_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Read_sigA_2_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Get_sigA_3_BaseAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_3_HighAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_3_TotalBytes(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_3_BitWidth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigA_3_Depth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Write_sigA_3_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Read_sigA_3_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Write_sigA_3_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Read_sigA_3_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Get_sigB_0_BaseAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_0_HighAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_0_TotalBytes(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_0_BitWidth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_0_Depth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Write_sigB_0_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Read_sigB_0_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Write_sigB_0_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Read_sigB_0_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Get_sigB_1_BaseAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_1_HighAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_1_TotalBytes(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_1_BitWidth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_1_Depth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Write_sigB_1_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Read_sigB_1_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Write_sigB_1_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Read_sigB_1_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Get_sigB_2_BaseAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_2_HighAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_2_TotalBytes(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_2_BitWidth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_2_Depth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Write_sigB_2_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Read_sigB_2_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Write_sigB_2_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Read_sigB_2_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Get_sigB_3_BaseAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_3_HighAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_3_TotalBytes(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_3_BitWidth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_sigB_3_Depth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Write_sigB_3_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Read_sigB_3_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Write_sigB_3_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Read_sigB_3_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Get_energia_BaseAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_energia_HighAddress(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_energia_TotalBytes(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_energia_BitWidth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Get_energia_Depth(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_Write_energia_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Read_energia_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length);
u32 XDiferencia_energia_Write_energia_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);
u32 XDiferencia_energia_Read_energia_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length);

void XDiferencia_energia_InterruptGlobalEnable(XDiferencia_energia *InstancePtr);
void XDiferencia_energia_InterruptGlobalDisable(XDiferencia_energia *InstancePtr);
void XDiferencia_energia_InterruptEnable(XDiferencia_energia *InstancePtr, u32 Mask);
void XDiferencia_energia_InterruptDisable(XDiferencia_energia *InstancePtr, u32 Mask);
void XDiferencia_energia_InterruptClear(XDiferencia_energia *InstancePtr, u32 Mask);
u32 XDiferencia_energia_InterruptGetEnabled(XDiferencia_energia *InstancePtr);
u32 XDiferencia_energia_InterruptGetStatus(XDiferencia_energia *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif

// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read/COR)
//         bit 4  - ap_continue (Read/Write/SC)
//         bit 7  - auto_restart (Read/Write)
//         bit 9  - interrupt (Read)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0 - enable ap_done interrupt (Read/Write)
//         bit 1 - enable ap_ready interrupt (Read/Write)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/TOW)
//         bit 0 - ap_done (Read/TOW)
//         bit 1 - ap_ready (Read/TOW)
//         others - reserved
// 0x100 ~
// 0x1ff : Memory 'sigA_0' (128 * 16b)
//         Word n : bit [15: 0] - sigA_0[2n]
//                  bit [31:16] - sigA_0[2n+1]
// 0x200 ~
// 0x2ff : Memory 'sigA_1' (128 * 16b)
//         Word n : bit [15: 0] - sigA_1[2n]
//                  bit [31:16] - sigA_1[2n+1]
// 0x300 ~
// 0x3ff : Memory 'sigA_2' (128 * 16b)
//         Word n : bit [15: 0] - sigA_2[2n]
//                  bit [31:16] - sigA_2[2n+1]
// 0x400 ~
// 0x4ff : Memory 'sigA_3' (128 * 16b)
//         Word n : bit [15: 0] - sigA_3[2n]
//                  bit [31:16] - sigA_3[2n+1]
// 0x500 ~
// 0x5ff : Memory 'sigB_0' (128 * 16b)
//         Word n : bit [15: 0] - sigB_0[2n]
//                  bit [31:16] - sigB_0[2n+1]
// 0x600 ~
// 0x6ff : Memory 'sigB_1' (128 * 16b)
//         Word n : bit [15: 0] - sigB_1[2n]
//                  bit [31:16] - sigB_1[2n+1]
// 0x700 ~
// 0x7ff : Memory 'sigB_2' (128 * 16b)
//         Word n : bit [15: 0] - sigB_2[2n]
//                  bit [31:16] - sigB_2[2n+1]
// 0x800 ~
// 0x8ff : Memory 'sigB_3' (128 * 16b)
//         Word n : bit [15: 0] - sigB_3[2n]
//                  bit [31:16] - sigB_3[2n+1]
// 0xa00 ~
// 0xbff : Memory 'energia' (128 * 32b)
//         Word n : bit [31:0] - energia[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define CONTROL_ADDR_AP_CTRL      0x000
#define CONTROL_ADDR_GIE          0x004
#define CONTROL_ADDR_IER          0x008
#define CONTROL_ADDR_ISR          0x00c
#define CONTROL_ADDR_SIGA_0_BASE  0x100
#define CONTROL_ADDR_SIGA_0_HIGH  0x1ff
#define CONTROL_WIDTH_SIGA_0      16
#define CONTROL_DEPTH_SIGA_0      128
#define CONTROL_ADDR_SIGA_1_BASE  0x200
#define CONTROL_ADDR_SIGA_1_HIGH  0x2ff
#define CONTROL_WIDTH_SIGA_1      16
#define CONTROL_DEPTH_SIGA_1      128
#define CONTROL_ADDR_SIGA_2_BASE  0x300
#define CONTROL_ADDR_SIGA_2_HIGH  0x3ff
#define CONTROL_WIDTH_SIGA_2      16
#define CONTROL_DEPTH_SIGA_2      128
#define CONTROL_ADDR_SIGA_3_BASE  0x400
#define CONTROL_ADDR_SIGA_3_HIGH  0x4ff
#define CONTROL_WIDTH_SIGA_3      16
#define CONTROL_DEPTH_SIGA_3      128
#define CONTROL_ADDR_SIGB_0_BASE  0x500
#define CONTROL_ADDR_SIGB_0_HIGH  0x5ff
#define CONTROL_WIDTH_SIGB_0      16
#define CONTROL_DEPTH_SIGB_0      128
#define CONTROL_ADDR_SIGB_1_BASE  0x600
#define CONTROL_ADDR_SIGB_1_HIGH  0x6ff
#define CONTROL_WIDTH_SIGB_1      16
#define CONTROL_DEPTH_SIGB_1      128
#define CONTROL_ADDR_SIGB_2_BASE  0x700
#define CONTROL_ADDR_SIGB_2_HIGH  0x7ff
#define CONTROL_WIDTH_SIGB_2      16
#define CONTROL_DEPTH_SIGB_2      128
#define CONTROL_ADDR_SIGB_3_BASE  0x800
#define CONTROL_ADDR_SIGB_3_HIGH  0x8ff
#define CONTROL_WIDTH_SIGB_3      16
#define CONTROL_DEPTH_SIGB_3      128
#define CONTROL_ADDR_ENERGIA_BASE 0xa00
#define CONTROL_ADDR_ENERGIA_HIGH 0xbff
#define CONTROL_WIDTH_ENERGIA     32
#define CONTROL_DEPTH_ENERGIA     128

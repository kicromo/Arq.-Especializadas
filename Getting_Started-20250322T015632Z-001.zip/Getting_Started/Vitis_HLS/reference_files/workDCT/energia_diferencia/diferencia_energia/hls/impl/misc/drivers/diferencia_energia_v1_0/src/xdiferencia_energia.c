// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xdiferencia_energia.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDiferencia_energia_CfgInitialize(XDiferencia_energia *InstancePtr, XDiferencia_energia_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDiferencia_energia_Start(XDiferencia_energia *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDiferencia_energia_ReadReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_AP_CTRL) & 0x80;
    XDiferencia_energia_WriteReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDiferencia_energia_IsDone(XDiferencia_energia *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDiferencia_energia_ReadReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDiferencia_energia_IsIdle(XDiferencia_energia *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDiferencia_energia_ReadReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDiferencia_energia_IsReady(XDiferencia_energia *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDiferencia_energia_ReadReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDiferencia_energia_Continue(XDiferencia_energia *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDiferencia_energia_ReadReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_AP_CTRL) & 0x80;
    XDiferencia_energia_WriteReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_AP_CTRL, Data | 0x10);
}

void XDiferencia_energia_EnableAutoRestart(XDiferencia_energia *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDiferencia_energia_WriteReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XDiferencia_energia_DisableAutoRestart(XDiferencia_energia *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDiferencia_energia_WriteReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XDiferencia_energia_Get_sigA_0_BaseAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE);
}

u32 XDiferencia_energia_Get_sigA_0_HighAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_HIGH);
}

u32 XDiferencia_energia_Get_sigA_0_TotalBytes(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE + 1);
}

u32 XDiferencia_energia_Get_sigA_0_BitWidth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_WIDTH_SIGA_0;
}

u32 XDiferencia_energia_Get_sigA_0_Depth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_DEPTH_SIGA_0;
}

u32 XDiferencia_energia_Write_sigA_0_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigA_0_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDiferencia_energia_Write_sigA_0_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigA_0_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_0_BASE + offset + i);
    }
    return length;
}

u32 XDiferencia_energia_Get_sigA_1_BaseAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE);
}

u32 XDiferencia_energia_Get_sigA_1_HighAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_HIGH);
}

u32 XDiferencia_energia_Get_sigA_1_TotalBytes(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE + 1);
}

u32 XDiferencia_energia_Get_sigA_1_BitWidth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_WIDTH_SIGA_1;
}

u32 XDiferencia_energia_Get_sigA_1_Depth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_DEPTH_SIGA_1;
}

u32 XDiferencia_energia_Write_sigA_1_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigA_1_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDiferencia_energia_Write_sigA_1_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigA_1_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_1_BASE + offset + i);
    }
    return length;
}

u32 XDiferencia_energia_Get_sigA_2_BaseAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE);
}

u32 XDiferencia_energia_Get_sigA_2_HighAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_HIGH);
}

u32 XDiferencia_energia_Get_sigA_2_TotalBytes(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE + 1);
}

u32 XDiferencia_energia_Get_sigA_2_BitWidth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_WIDTH_SIGA_2;
}

u32 XDiferencia_energia_Get_sigA_2_Depth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_DEPTH_SIGA_2;
}

u32 XDiferencia_energia_Write_sigA_2_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigA_2_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDiferencia_energia_Write_sigA_2_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigA_2_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_2_BASE + offset + i);
    }
    return length;
}

u32 XDiferencia_energia_Get_sigA_3_BaseAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE);
}

u32 XDiferencia_energia_Get_sigA_3_HighAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_HIGH);
}

u32 XDiferencia_energia_Get_sigA_3_TotalBytes(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE + 1);
}

u32 XDiferencia_energia_Get_sigA_3_BitWidth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_WIDTH_SIGA_3;
}

u32 XDiferencia_energia_Get_sigA_3_Depth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_DEPTH_SIGA_3;
}

u32 XDiferencia_energia_Write_sigA_3_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigA_3_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDiferencia_energia_Write_sigA_3_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigA_3_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGA_3_BASE + offset + i);
    }
    return length;
}

u32 XDiferencia_energia_Get_sigB_0_BaseAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE);
}

u32 XDiferencia_energia_Get_sigB_0_HighAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_HIGH);
}

u32 XDiferencia_energia_Get_sigB_0_TotalBytes(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE + 1);
}

u32 XDiferencia_energia_Get_sigB_0_BitWidth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_WIDTH_SIGB_0;
}

u32 XDiferencia_energia_Get_sigB_0_Depth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_DEPTH_SIGB_0;
}

u32 XDiferencia_energia_Write_sigB_0_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigB_0_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDiferencia_energia_Write_sigB_0_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigB_0_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_0_BASE + offset + i);
    }
    return length;
}

u32 XDiferencia_energia_Get_sigB_1_BaseAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE);
}

u32 XDiferencia_energia_Get_sigB_1_HighAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_HIGH);
}

u32 XDiferencia_energia_Get_sigB_1_TotalBytes(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE + 1);
}

u32 XDiferencia_energia_Get_sigB_1_BitWidth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_WIDTH_SIGB_1;
}

u32 XDiferencia_energia_Get_sigB_1_Depth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_DEPTH_SIGB_1;
}

u32 XDiferencia_energia_Write_sigB_1_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigB_1_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDiferencia_energia_Write_sigB_1_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigB_1_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_1_BASE + offset + i);
    }
    return length;
}

u32 XDiferencia_energia_Get_sigB_2_BaseAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE);
}

u32 XDiferencia_energia_Get_sigB_2_HighAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_HIGH);
}

u32 XDiferencia_energia_Get_sigB_2_TotalBytes(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE + 1);
}

u32 XDiferencia_energia_Get_sigB_2_BitWidth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_WIDTH_SIGB_2;
}

u32 XDiferencia_energia_Get_sigB_2_Depth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_DEPTH_SIGB_2;
}

u32 XDiferencia_energia_Write_sigB_2_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigB_2_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDiferencia_energia_Write_sigB_2_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigB_2_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_2_BASE + offset + i);
    }
    return length;
}

u32 XDiferencia_energia_Get_sigB_3_BaseAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE);
}

u32 XDiferencia_energia_Get_sigB_3_HighAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_HIGH);
}

u32 XDiferencia_energia_Get_sigB_3_TotalBytes(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE + 1);
}

u32 XDiferencia_energia_Get_sigB_3_BitWidth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_WIDTH_SIGB_3;
}

u32 XDiferencia_energia_Get_sigB_3_Depth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_DEPTH_SIGB_3;
}

u32 XDiferencia_energia_Write_sigB_3_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigB_3_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDiferencia_energia_Write_sigB_3_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_sigB_3_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_SIGB_3_BASE + offset + i);
    }
    return length;
}

u32 XDiferencia_energia_Get_energia_BaseAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE);
}

u32 XDiferencia_energia_Get_energia_HighAddress(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_HIGH);
}

u32 XDiferencia_energia_Get_energia_TotalBytes(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE + 1);
}

u32 XDiferencia_energia_Get_energia_BitWidth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_WIDTH_ENERGIA;
}

u32 XDiferencia_energia_Get_energia_Depth(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDIFERENCIA_ENERGIA_CONTROL_DEPTH_ENERGIA;
}

u32 XDiferencia_energia_Write_energia_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_energia_Words(XDiferencia_energia *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDiferencia_energia_Write_energia_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDiferencia_energia_Read_energia_Bytes(XDiferencia_energia *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_HIGH - XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDIFERENCIA_ENERGIA_CONTROL_ADDR_ENERGIA_BASE + offset + i);
    }
    return length;
}

void XDiferencia_energia_InterruptGlobalEnable(XDiferencia_energia *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDiferencia_energia_WriteReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_GIE, 1);
}

void XDiferencia_energia_InterruptGlobalDisable(XDiferencia_energia *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDiferencia_energia_WriteReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_GIE, 0);
}

void XDiferencia_energia_InterruptEnable(XDiferencia_energia *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDiferencia_energia_ReadReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_IER);
    XDiferencia_energia_WriteReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_IER, Register | Mask);
}

void XDiferencia_energia_InterruptDisable(XDiferencia_energia *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDiferencia_energia_ReadReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_IER);
    XDiferencia_energia_WriteReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_IER, Register & (~Mask));
}

void XDiferencia_energia_InterruptClear(XDiferencia_energia *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDiferencia_energia_WriteReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_ISR, Mask);
}

u32 XDiferencia_energia_InterruptGetEnabled(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDiferencia_energia_ReadReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_IER);
}

u32 XDiferencia_energia_InterruptGetStatus(XDiferencia_energia *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDiferencia_energia_ReadReg(InstancePtr->Control_BaseAddress, XDIFERENCIA_ENERGIA_CONTROL_ADDR_ISR);
}


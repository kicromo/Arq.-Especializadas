// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xdiferencia_energia.h"

extern XDiferencia_energia_Config XDiferencia_energia_ConfigTable[];

#ifdef SDT
XDiferencia_energia_Config *XDiferencia_energia_LookupConfig(UINTPTR BaseAddress) {
	XDiferencia_energia_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XDiferencia_energia_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XDiferencia_energia_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XDiferencia_energia_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDiferencia_energia_Initialize(XDiferencia_energia *InstancePtr, UINTPTR BaseAddress) {
	XDiferencia_energia_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDiferencia_energia_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDiferencia_energia_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XDiferencia_energia_Config *XDiferencia_energia_LookupConfig(u16 DeviceId) {
	XDiferencia_energia_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDIFERENCIA_ENERGIA_NUM_INSTANCES; Index++) {
		if (XDiferencia_energia_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDiferencia_energia_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDiferencia_energia_Initialize(XDiferencia_energia *InstancePtr, u16 DeviceId) {
	XDiferencia_energia_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDiferencia_energia_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDiferencia_energia_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

